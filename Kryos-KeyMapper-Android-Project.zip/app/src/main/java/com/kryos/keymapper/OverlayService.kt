package com.kryos.keymapper

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

class OverlayService : Service() {
    private var window: LinearLayout? = null
    private lateinit var wm: WindowManager
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(0xCC172033.toInt())
        }
        val title = Button(this).apply { text = "KRYOS • kéo bảng"; isAllCaps = false }
        panel.addView(title)
        val rows = listOf(listOf("W", "J"), listOf("A", "S", "D", "K"))
        rows.flatten().forEach { label ->
            panel.addView(Button(this).apply {
                text = "Chạm $label"
                isAllCaps = false
                setOnClickListener {
                    val m = MappingStore.all(this@OverlayService).first { it.label == label }
                    val service = KeyMapperAccessibilityService.instance
                    if (service == null) Toast.makeText(this@OverlayService, "Hãy bật quyền Trợ năng", Toast.LENGTH_SHORT).show()
                    else service.tapPercent(m.x, m.y)
                }
            })
        }
        val close = Button(this).apply { text = "Đóng bảng"; setOnClickListener { stopSelf() } }
        panel.addView(close)
        val type = overlayWindowType()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 12; y = 120 }
        window = panel
        wm.addView(panel, params)
        title.setOnTouchListener(object : android.view.View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: android.view.View, e: android.view.MotionEvent): Boolean {
                when (e.action) {
                    android.view.MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=params.x; oy=params.y; return true }
                    android.view.MotionEvent.ACTION_MOVE -> { params.x=ox+(e.rawX-sx).toInt(); params.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(panel, params); return true }
                }
                return false
            }
        })
    }
    @Suppress("DEPRECATION")
    private fun overlayWindowType(): Int = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    override fun onDestroy() { window?.let { wm.removeView(it) }; window = null; super.onDestroy() }
}
