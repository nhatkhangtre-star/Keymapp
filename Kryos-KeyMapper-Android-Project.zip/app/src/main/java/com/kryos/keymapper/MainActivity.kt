package com.kryos.keymapper

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF10131B.toInt())
        }
        fun text(s: String, size: Float, color: Int = 0xFFFFFFFF.toInt()) =
            TextView(this).apply { text = s; textSize = size; setTextColor(color); setPadding(0, 10, 0, 10) }
        root.addView(text("KRYOS KEYMAPPER", 25f, 0xFF70D6FF.toInt()))
        root.addView(text("Bản thử nghiệm 1.0 • Android 8 trở lên", 14f, 0xFFB8C2D1.toInt()))
        status = text("", 15f, 0xFF8BE9A8.toInt())
        root.addView(status)
        root.addView(text("CÁCH KẾT NỐI", 17f, 0xFFFFD166.toInt()))
        root.addView(action("1. Bật quyền Trợ năng") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(action("2. Cấp quyền hiển thị trên ứng dụng khác") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else toast("Quyền cửa sổ nổi đã được cấp")
        })
        root.addView(action("3. Bật bảng nút nổi") {
            if (!Settings.canDrawOverlays(this)) toast("Hãy cấp quyền cửa sổ nổi trước")
            else { startService(Intent(this, OverlayService::class.java)); toast("Đã bật bảng nút nổi") }
        })
        root.addView(action("Tắt bảng nút nổi") { stopService(Intent(this, OverlayService::class.java)) })
        root.addView(text("PHÍM MẶC ĐỊNH", 17f, 0xFFFFD166.toInt()))
        root.addView(text("W / A / S / D: các điểm điều khiển di chuyển\nJ / K: hai điểm thao tác bên phải\nCác vị trí mặc định là tương đối theo màn hình.", 15f, 0xFFE4EAF2.toInt()))
        root.addView(text("LƯU Ý: Bản 1.0 thực hiện chạm đơn tại tọa độ. Chưa hỗ trợ joystick analog, giữ nhiều điểm chạm đồng thời hoặc mọi game. Một số game có thể chặn thao tác trợ năng/overlay.", 13f, 0xFFFFB4A2.toInt()))
        root.addView(text("Chỉ dùng trong game cho phép công cụ hỗ trợ điều khiển; không dùng để vượt anti-cheat.", 12f, 0xFFB8C2D1.toInt()))
        setContentView(root)
    }
    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() {
        status.text = if (KeyMapperAccessibilityService.instance != null) "● Dịch vụ phím: đang bật" else "● Dịch vụ phím: chưa bật"
    }
    private fun action(label: String, run: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { run() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
