package com.kryos.keymapper

import android.content.Context
import android.view.KeyEvent

data class Mapping(val keyCode: Int, val label: String, val x: Float, val y: Float)

object MappingStore {
    private const val PREF = "kryos_mappings"
    private val defaults = listOf(
        Mapping(KeyEvent.KEYCODE_W, "W", .50f, .72f),
        Mapping(KeyEvent.KEYCODE_A, "A", .40f, .82f),
        Mapping(KeyEvent.KEYCODE_S, "S", .50f, .88f),
        Mapping(KeyEvent.KEYCODE_D, "D", .60f, .82f),
        Mapping(KeyEvent.KEYCODE_J, "J", .82f, .76f),
        Mapping(KeyEvent.KEYCODE_K, "K", .90f, .66f)
    )
    fun all(context: Context): List<Mapping> {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        return defaults.map { m ->
            Mapping(m.keyCode, m.label,
                p.getFloat("${m.label}_x", m.x),
                p.getFloat("${m.label}_y", m.y))
        }
    }
    fun save(context: Context, label: String, xPercent: Float, yPercent: Float) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putFloat("${label}_x", xPercent.coerceIn(0f, 1f))
            .putFloat("${label}_y", yPercent.coerceIn(0f, 1f)).apply()
    }
}
