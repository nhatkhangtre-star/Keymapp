package com.kryos.keymapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.util.DisplayMetrics
import android.view.WindowManager

class KeyMapperAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: KeyMapperAccessibilityService? = null }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { instance = null }
    override fun onDestroy() { instance = null; super.onDestroy() }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount != 0) return false
        val mapping = MappingStore.all(this).firstOrNull { it.keyCode == event.keyCode } ?: return false
        tapPercent(mapping.x, mapping.y)
        return true
    }

    fun tapPercent(xPercent: Float, yPercent: Float) {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val x = (metrics.widthPixels * xPercent).coerceIn(1f, metrics.widthPixels - 1f)
        val y = (metrics.heightPixels * yPercent).coerceIn(1f, metrics.heightPixels - 1f)
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 70)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }
}
