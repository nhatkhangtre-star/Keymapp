# Kryos KeyMapper Android

Bản MVP: nhận phím cứng W/A/S/D/J/K qua AccessibilityService và tạo thao tác chạm đơn tại các tọa độ tương đối; có bảng nút nổi để chạm thủ công.

## Giới hạn
- Không phải mọi game cho phép AccessibilityService, overlay hoặc thao tác chạm mô phỏng.
- Bản này chưa hỗ trợ joystick analog, nhiều ngón tay/đa điểm đồng thời, giữ liên tục, hoặc bảo đảm tương thích mọi game.
- Chỉ sử dụng trong trò chơi cho phép công cụ hỗ trợ điều khiển. Không dùng để né/vượt anti-cheat.
- Người dùng phải tự bật Accessibility và cấp quyền overlay trong Android Settings.

## Build qua GitHub
1. Upload file `KeyMapper-AndroidStudio-Project.zip` vào repository ở thư mục gốc.
2. Upload file workflow `.github/workflows/build-apk.yml` ở ngoài ZIP vào đúng đường dẫn trong repository.
3. Vào Actions và chạy `Build Kryos KeyMapper APK`.
4. Tải artifact `Kryos-KeyMapper-debug`; giải nén artifact để lấy `app-debug.apk`.
